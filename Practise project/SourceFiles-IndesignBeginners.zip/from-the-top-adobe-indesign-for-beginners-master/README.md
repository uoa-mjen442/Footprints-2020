## Envato Tuts+ Course: From the Top: Adobe InDesign for Beginners
### Instructor: [Dan Scott](https://tutsplus.com/authors/daniel-walter-scott)
